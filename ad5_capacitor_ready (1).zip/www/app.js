const DEMO_RAND_PER_CLIP = 0.10; // Illustrative test value only; never payable.
let points=Number(localStorage.getItem('ad5_points')||0);
let views=Number(localStorage.getItem('ad5_views')||0);
let demoRand=Number(localStorage.getItem('ad5_demo_rand')||0);
let transactions=JSON.parse(localStorage.getItem('ad5_demo_transactions')||'[]');
let busy=false;
const $=id=>document.getElementById(id);
const zar=value=>'R'+Number(value).toFixed(2);
function saveWallet(){
  localStorage.setItem('ad5_demo_rand',demoRand.toFixed(2));
  localStorage.setItem('ad5_demo_transactions',JSON.stringify(transactions));
}
function renderWallet(){
  $('walletAvailable').textContent=zar(demoRand);
  $('walletPending').textContent=zar(0);
  $('walletTotal').textContent=zar(demoRand);
  const list=$('transactions');
  if(!transactions.length){
    list.innerHTML='<p class="empty">No demo activity yet. Complete a sample clip to see a test entry here.</p>';
    return;
  }
  list.innerHTML=transactions.slice().reverse().map(tx=>
    `<div class="transaction"><div><b>${tx.title}</b><small>${tx.date} · simulated</small></div><strong>+${zar(tx.amount)}</strong></div>`
  ).join('');
}
function render(){
  $('points').textContent=points.toLocaleString();
  $('views').textContent=views+' / 10';
  $('watch').disabled=busy||views>=10;
  renderWallet();
}
document.querySelectorAll('nav button').forEach(b=>b.addEventListener('click',()=>{
  document.querySelectorAll('nav button').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));
  $(b.dataset.page).classList.remove('hidden');
}));
$('watch').addEventListener('click',()=>{
  if(busy||views>=10)return;
  busy=true;render();
  let t=5;
  $('timerLabel').textContent='Demo countdown: '+t+'s';
  $('video').querySelector('.play').textContent='⏳';
  const timer=setInterval(()=>{
    t--;
    $('timerLabel').textContent='Demo countdown: '+t+'s';
    if(t<=0){
      clearInterval(timer);
      points+=10;views++;
      demoRand=Number((demoRand+DEMO_RAND_PER_CLIP).toFixed(2));
      transactions.push({title:'Completed 5-second demo clip',amount:DEMO_RAND_PER_CLIP,date:new Date().toLocaleString()});
      localStorage.setItem('ad5_points',points);
      localStorage.setItem('ad5_views',views);
      saveWallet();
      $('timerLabel').textContent='Demo complete — +10 points';
      $('video').querySelector('.play').textContent='✓';
      busy=false;render();
    }
  },1000);
});
$('copy').addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText('AD5-DEMO');$('copy').textContent='Copied demo code!'}
  catch{$('copy').textContent='Code: AD5-DEMO'}
});
render();
