# Ad5 Rewards ZA — Capacitor Android demo

## Build
1. Install Node.js LTS and Android Studio.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run `npm install`.
5. Run `npx cap add android`.
6. Run `npx cap sync android`.
7. Run `npx cap open android`.
8. In Android Studio, choose Build > Build Bundle(s) / APK(s) > Build APK(s).

## Demo wallet
The Wallet tab displays simulated South African Rand (ZAR) values. Each completed sample clip adds R0.10 to the on-device demo display and 10 demo points. This is only an illustrative test value: it is not real money, cannot be withdrawn or redeemed, and no payment provider, advertiser, or backend is connected. Data is stored locally on the device.

This is a prototype, not a financial product.
