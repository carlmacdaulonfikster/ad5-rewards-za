# Ad5 Rewards ZA — Capacitor Android wrapper

1. Install Node.js LTS and Android Studio.
2. Extract this ZIP.
3. Open a terminal in the extracted folder.
4. Run: `npm install`
5. Run: `npx cap add android`
6. Run: `npx cap sync android`
7. Run: `npx cap open android`
8. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

This is a demo only. Points have no monetary value and no advertisers, payments, or backend are connected.
