/* Public client config only. Publishable keys are intended for client apps. Never put service-role/secret keys here. */
window.AD5_CONFIG = {
  SUPABASE_URL: "https://phdtmathewgcybrfwbtg.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_45AbP-NLAeBkuaPPg032xA_YbXgulTx"
};
