-- AD5 Rewards ZA core schema. Apply with Supabase migrations.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  phone_e164 text,
  kyc_status text not null default 'unverified' check (kyc_status in ('unverified','pending','verified','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  currency char(3) not null default 'ZAR' check (currency = 'ZAR'),
  available_cents bigint not null default 0 check (available_cents >= 0),
  pending_cents bigint not null default 0 check (pending_cents >= 0),
  total_earned_cents bigint not null default 0 check (total_earned_cents >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.sponsor_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text not null,
  user_id uuid not null references auth.users(id),
  amount_cents bigint not null check (amount_cents > 0),
  currency char(3) not null default 'ZAR' check (currency = 'ZAR'),
  status text not null default 'verified' check (status in ('verified','reversed')),
  received_at timestamptz not null default now(),
  unique(provider, provider_event_id)
);

create table if not exists public.wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  entry_type text not null check (entry_type in ('sponsor_reward','withdrawal_reservation','withdrawal_release','adjustment','reversal')),
  amount_cents bigint not null check (amount_cents <> 0),
  available_after_cents bigint not null check (available_after_cents >= 0),
  reference text not null,
  description text not null,
  created_at timestamptz not null default now(),
  unique(entry_type, reference)
);

create table if not exists public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount_cents bigint not null check (amount_cents > 0),
  currency char(3) not null default 'ZAR' check (currency = 'ZAR'),
  status text not null default 'queued_for_review' check (status in ('queued_for_review','approved','processing','paid','rejected','cancelled')),
  payout_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists wallet_ledger_user_created_idx on public.wallet_ledger(user_id, created_at desc);
create index if not exists withdrawals_user_created_idx on public.withdrawal_requests(user_id, created_at desc);

-- Create profile and zero-balance wallet for each newly registered user.
create or replace function public.handle_new_ad5_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id, display_name) values (new.id, coalesce(new.raw_user_meta_data->>'display_name','')) on conflict do nothing;
  insert into public.wallets(user_id) values (new.id) on conflict do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_ad5 on auth.users;
create trigger on_auth_user_created_ad5 after insert on auth.users
for each row execute procedure public.handle_new_ad5_user();

-- Server-only, idempotent credit operation. A provider event can be credited once only.
create or replace function public.credit_verified_sponsor_event(
  p_provider text,
  p_provider_event_id text,
  p_user_id uuid,
  p_amount_cents bigint
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_wallet public.wallets%rowtype;
  v_event_id uuid;
  v_new_available bigint;
begin
  if p_provider is null or length(trim(p_provider)) = 0 or length(p_provider) > 80 then raise exception 'invalid_provider'; end if;
  if p_provider_event_id is null or length(trim(p_provider_event_id)) = 0 or length(p_provider_event_id) > 200 then raise exception 'invalid_event_id'; end if;
  if p_amount_cents is null or p_amount_cents <= 0 or p_amount_cents > 1000000 then raise exception 'invalid_amount'; end if;

  select * into v_wallet from public.wallets where user_id = p_user_id for update;
  if not found then raise exception 'wallet_not_found'; end if;

  insert into public.sponsor_events(provider, provider_event_id, user_id, amount_cents)
  values (p_provider, p_provider_event_id, p_user_id, p_amount_cents)
  on conflict (provider, provider_event_id) do nothing
  returning id into v_event_id;

  if v_event_id is null then
    return jsonb_build_object('ok', true, 'duplicate', true);
  end if;

  v_new_available := v_wallet.available_cents + p_amount_cents;
  update public.wallets set available_cents = v_new_available,
    total_earned_cents = total_earned_cents + p_amount_cents, updated_at = now()
  where user_id = p_user_id;

  insert into public.wallet_ledger(user_id, entry_type, amount_cents, available_after_cents, reference, description)
  values (p_user_id, 'sponsor_reward', p_amount_cents, v_new_available,
    p_provider || ':' || p_provider_event_id, 'Verified sponsor reward');

  return jsonb_build_object('ok', true, 'duplicate', false, 'event_id', v_event_id, 'credited_cents', p_amount_cents);
end;
$$;

-- No client may execute privileged credit RPC directly.
revoke all on function public.credit_verified_sponsor_event(text,text,uuid,bigint) from public, anon, authenticated;
grant execute on function public.credit_verified_sponsor_event(text,text,uuid,bigint) to service_role;

-- Clients can read only their own wallet/profile/ledger/withdrawal history.
alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.sponsor_events enable row level security;

create policy "profile_select_own" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "profile_update_own_limited" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
create policy "wallet_select_own" on public.wallets for select to authenticated using (user_id = (select auth.uid()));
create policy "ledger_select_own" on public.wallet_ledger for select to authenticated using (user_id = (select auth.uid()));
create policy "withdrawals_select_own" on public.withdrawal_requests for select to authenticated using (user_id = (select auth.uid()));

-- Explicitly deny direct client writes to financial records.
revoke insert, update, delete on public.wallets, public.wallet_ledger, public.sponsor_events, public.withdrawal_requests from anon, authenticated;
revoke insert, delete on public.profiles from anon, authenticated;
grant select on public.profiles, public.wallets, public.wallet_ledger, public.withdrawal_requests to authenticated;
grant update(display_name, phone_e164) on public.profiles to authenticated;

-- Ledger rows are append-only, including for privileged application roles.
create or replace function public.prevent_ad5_ledger_mutation()
returns trigger language plpgsql set search_path = '' as $$
begin raise exception 'wallet_ledger_is_append_only'; end;
$$;
drop trigger if exists wallet_ledger_no_update on public.wallet_ledger;
create trigger wallet_ledger_no_update before update or delete on public.wallet_ledger
for each row execute function public.prevent_ad5_ledger_mutation();
