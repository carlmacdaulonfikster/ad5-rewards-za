import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json, env } from '../_shared/http.ts';

// Deliberately closed until KYC, a regulated/contracted payout provider, admin review,
// reconciliation, and customer-support procedures have been implemented and tested.
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return json({ error: 'unauthorized' }, 401);
  const token = auth.slice(7);
  const client = createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), { auth: { persistSession: false } });
  const { data, error } = await client.auth.getUser(token);
  if (error || !data.user) return json({ error: 'unauthorized' }, 401);
  return json({ error: 'withdrawals_not_activated', message: 'Withdrawals are disabled until AD5 completes identity checks, provider integration, payout controls and reconciliation.' }, 423);
});
