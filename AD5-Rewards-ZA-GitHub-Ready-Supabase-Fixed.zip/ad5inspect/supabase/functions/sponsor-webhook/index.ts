import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders, json, env } from '../_shared/http.ts';

function toHex(bytes: ArrayBuffer) { return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join(''); }
async function hmacHex(secret: string, message: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return toHex(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(message)));
}
function constantTimeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const raw = await req.text();
  const supplied = (req.headers.get('x-ad5-signature') || '').replace(/^sha256=/, '').toLowerCase();
  const expected = await hmacHex(env('AD5_SPONSOR_WEBHOOK_SECRET'), raw);
  if (!supplied || !constantTimeEqual(supplied, expected)) return json({ error: 'invalid_signature' }, 401);
  let body: Record<string, unknown>;
  try { body = JSON.parse(raw); } catch { return json({ error: 'invalid_json' }, 400); }
  const provider = typeof body.provider === 'string' ? body.provider : '';
  const eventId = typeof body.event_id === 'string' ? body.event_id : '';
  const userId = typeof body.user_id === 'string' ? body.user_id : '';
  const amountCents = Number(body.amount_cents);
  if (!provider || !eventId || !userId || !Number.isSafeInteger(amountCents) || amountCents <= 0) return json({ error: 'invalid_event' }, 400);
  const admin = createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });
  const { data, error } = await admin.rpc('credit_verified_sponsor_event', { p_provider: provider, p_provider_event_id: eventId, p_user_id: userId, p_amount_cents: amountCents });
  if (error) return json({ error: 'credit_failed' }, 400);
  return json(data);
});
