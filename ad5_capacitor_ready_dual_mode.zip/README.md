# AD5 Rewards ZA — Dual-mode Capacitor MVP

This source package adds a visible Demo / Real-money mode switch while keeping demo credits isolated from the real-money account.

## Current functionality

### Demo testing mode
- Preserves the existing sample 5-second clip flow.
- Each completed sample clip adds 10 demo points and R0.10 of illustrative demo value.
- Demo balance and sample transaction history are stored locally on the device.
- Demo values are not cash, are not redeemable and cannot be withdrawn.
- Demo credits are never copied to the real-money wallet.

### Real-money mode (UI prepared, NOT live)
- Provides a separate real-wallet screen and real-account status.
- Does not create cash earnings, accept deposits or enable withdrawals.
- Real balance/transactions are deliberately not stored in localStorage and must come from a secure authenticated backend.
- No payment provider, bank account, advertiser, identity verification or live backend is connected in this package.

## Important security boundary
Do not put payment-provider secret keys, private API keys, bank credentials or signing secrets in `www/config.js` or any Android APK. APK contents can be inspected. Real earnings must be credited by a server after a sponsor event is verified. The server must own the authoritative ledger and prevent duplicate event processing. Withdrawals must be authenticated, risk-checked and sent through a legitimate provider from the server only.

## Suggested backend API contract (not implemented here)
- `GET /v1/me/wallet` — authenticated user's ZAR available/pending/total balances and transaction history.
- `POST /v1/earning-events/verify` — server-to-server verified sponsor event; idempotent event ID required.
- `POST /v1/me/withdrawals` — authenticated withdrawal request; server checks identity, available balance, minimum/fees and provider status.
- `GET /v1/me/withdrawals` — user's withdrawal status/history.
- Admin-only endpoints for reconciliation, reversals, fraud review and payout approvals.

Use integer cents in the backend ledger (for example, R0.10 = 10 cents), not floating-point arithmetic. Record immutable ledger entries and provider references. Never trust a client-supplied amount or a client-side video countdown as proof of an earning.

## Configure backend later
`www/config.js` currently has an empty `API_BASE_URL`. It is intentionally not connected. A secure account sign-in/token flow and backend must be implemented before live mode can display a real balance or submit withdrawals. Do not add a secret token to this file.

## Build Android APK
1. Extract this ZIP.
2. Run `npm install`.
3. Run `npx cap add android` (only if the `android` folder does not already exist).
4. Run `npx cap sync android`.
5. Build the APK in Android Studio, or use the repository's GitHub Actions workflow.

## GitHub Actions extraction note
The workflow must extract the exact uploaded ZIP filename. This package is named `ad5_capacitor_ready_dual_mode.zip`. Update the unzip step to match that name, or use a wildcard only if the repository contains exactly one intended source ZIP.

This is a software prototype, not a financial product or a promise of earnings.
