'use strict';

// Demo-only credit. It is never sent to or copied into the real-money wallet.
const DEMO_RAND_PER_CLIP = 0.10;
const DEMO_POINTS_PER_CLIP = 10;
const DEMO_DAILY_LIMIT = 10;
const $ = id => document.getElementById(id);
const zar = value => 'R' + Number(value).toFixed(2);

let mode = localStorage.getItem('ad5_mode') === 'real' ? 'real' : 'demo';
let points = Number(localStorage.getItem('ad5_points') || 0);
let views = Number(localStorage.getItem('ad5_views') || 0);
let demoRand = Number(localStorage.getItem('ad5_demo_rand') || 0);
let transactions = safeJson(localStorage.getItem('ad5_demo_transactions'), []);
let busy = false;
let realWallet = null;

function safeJson(raw, fallback) {
  try { const value = JSON.parse(raw); return Array.isArray(value) ? value : fallback; }
  catch { return fallback; }
}
function saveDemoWallet() {
  localStorage.setItem('ad5_demo_rand', demoRand.toFixed(2));
  localStorage.setItem('ad5_demo_transactions', JSON.stringify(transactions));
  localStorage.setItem('ad5_points', String(points));
  localStorage.setItem('ad5_views', String(views));
}
function renderDemoWallet() {
  $('walletAvailable').textContent = zar(demoRand);
  $('walletPending').textContent = 'R0.00';
  $('walletTotal').textContent = zar(demoRand);
  const list = $('transactions');
  if (!transactions.length) {
    list.innerHTML = '<p class="empty">No demo activity yet. Complete a sample clip to see a test entry here.</p>';
    return;
  }
  list.innerHTML = transactions.slice().reverse().map(tx =>
    `<div class="transaction"><div><b>${escapeHtml(tx.title)}</b><small>${escapeHtml(tx.date)} · simulated</small></div><strong>+${zar(tx.amount)}</strong></div>`
  ).join('');
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function renderMode() {
  const isDemo = mode === 'demo';
  $('demoMode').classList.toggle('active', isDemo);
  $('realMode').classList.toggle('active', !isDemo);
  $('modeNotice').className = 'notice ' + (isDemo ? 'demo-notice' : 'warning-notice');
  $('modeNotice').innerHTML = isDemo
    ? '<b>DEMO MODE</b><span>Test credits only. They have no cash value and cannot be withdrawn.</span>'
    : '<b>REAL-MONEY MODE · NOT ACTIVATED</b><span>Live payments remain locked until the secure backend and payment provider are connected.</span>';
  $('topBalanceLabel').textContent = isDemo ? 'DEMO POINTS BALANCE' : 'REAL ACCOUNT STATUS';
  $('points').textContent = isDemo ? points.toLocaleString() : '—';
  $('pointsUnit').textContent = isDemo ? 'pts' : 'not linked';
  $('topBalanceNote').textContent = isDemo
    ? 'Points are simulated. No cash or rewards are payable in this demo.'
    : 'Your real-money balance must come from the verified AD5 server. No live account is connected.';
  $('demoEarnCard').classList.toggle('hidden', !isDemo);
  $('realEarnCard').classList.toggle('hidden', isDemo);
  $('demoWallet').classList.toggle('hidden', !isDemo);
  $('realWallet').classList.toggle('hidden', isDemo);
  $('howItWorks').textContent = isDemo
    ? 'Choose a sample clip → watch the countdown → collect demo points → explore the test wallet.'
    : 'Real rewards will be credited only after an advertiser event is verified by the AD5 server.';
  $('rewardIntro').textContent = isDemo
    ? 'Demo points and sample Rand amounts cannot be redeemed. Real rewards will only appear after sponsor funding and server verification.'
    : 'Real rewards are not active yet. They require a funded sponsor campaign and server verification.';
  $('views').textContent = views + ' / ' + DEMO_DAILY_LIMIT;
  $('watch').disabled = busy || views >= DEMO_DAILY_LIMIT;
}
function renderRealWallet() {
  // Live money is read only from the authenticated server. Never use local demo storage.
  if (!realWallet) return;
  $('realAvailable').textContent = zar(realWallet.available_balance);
  $('realPending').textContent = zar(realWallet.pending_balance);
  $('realTotal').textContent = zar(realWallet.total_earned);
  $('realWalletMessage').textContent = 'Balance supplied by the AD5 server.';
  const items = Array.isArray(realWallet.transactions) ? realWallet.transactions : [];
  $('realTransactions').innerHTML = items.length ? items.map(tx =>
    `<div class="transaction"><div><b>${escapeHtml(tx.description || 'Wallet transaction')}</b><small>${escapeHtml(tx.created_at || '')}</small></div><strong>${escapeHtml(tx.amount_formatted || '')}</strong></div>`
  ).join('') : '<p class="empty">No verified transactions yet.</p>';
}
async function loadRealWallet() {
  const base = window.AD5_CONFIG && window.AD5_CONFIG.API_BASE_URL;
  if (!base) return; // Intentionally locked until a real backend URL and auth flow exist.
  $('realWalletMessage').textContent = 'A backend URL is configured, but account sign-in is still required.';
  // Do not add a client-side API secret or trust a balance calculated on this device.
  // The authenticated API integration belongs here once the backend and auth provider exist.
}
function render() {
  $('views').textContent = views + ' / ' + DEMO_DAILY_LIMIT;
  $('watch').disabled = busy || views >= DEMO_DAILY_LIMIT;
  renderDemoWallet();
  renderMode();
  renderRealWallet();
}

$('demoMode').addEventListener('click', () => {
  mode = 'demo'; localStorage.setItem('ad5_mode', mode); render();
});
$('realMode').addEventListener('click', () => {
  mode = 'real'; localStorage.setItem('ad5_mode', mode); render(); loadRealWallet();
});
document.querySelectorAll('nav button').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('nav button').forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  document.querySelectorAll('.page').forEach(page => page.classList.add('hidden'));
  $(button.dataset.page).classList.remove('hidden');
  if (button.dataset.page === 'wallet' && mode === 'real') loadRealWallet();
}));
$('watch').addEventListener('click', () => {
  if (mode !== 'demo' || busy || views >= DEMO_DAILY_LIMIT) return;
  busy = true; render();
  let seconds = 5;
  $('timerLabel').textContent = 'Demo countdown: ' + seconds + 's';
  $('video').querySelector('.play').textContent = '⏳';
  const timer = setInterval(() => {
    seconds--;
    $('timerLabel').textContent = 'Demo countdown: ' + seconds + 's';
    if (seconds <= 0) {
      clearInterval(timer);
      points += DEMO_POINTS_PER_CLIP; views++;
      demoRand = Number((demoRand + DEMO_RAND_PER_CLIP).toFixed(2));
      transactions.push({title:'Completed 5-second demo clip', amount:DEMO_RAND_PER_CLIP, date:new Date().toLocaleString()});
      saveDemoWallet();
      $('timerLabel').textContent = 'Demo complete — +10 points';
      $('video').querySelector('.play').textContent = '✓';
      busy = false; render();
    }
  }, 1000);
});
$('copy').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText('AD5-DEMO'); $('copy').textContent = 'Copied demo code!'; }
  catch { $('copy').textContent = 'Code: AD5-DEMO'; }
});
render();
