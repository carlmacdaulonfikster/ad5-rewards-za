/* Public client configuration only. Never put payment secrets or private API keys here. */
window.AD5_CONFIG = {
  API_BASE_URL: ""
};
