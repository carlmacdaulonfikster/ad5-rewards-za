import { createClient } from '@supabase/supabase-js';
'use strict';

// Demo-only credit. It is never sent to or copied into the real-money wallet.
const DEMO_RAND_PER_CLIP = 0.10;
const DEMO_POINTS_PER_CLIP = 10;
const DEMO_DAILY_LIMIT = 10;
const $ = id => document.getElementById(id);
const zar = value => 'R' + Number(value).toFixed(2);
const cfg = window.AD5_CONFIG || {};
const supabaseReady = typeof cfg.SUPABASE_URL === 'string' && cfg.SUPABASE_URL.startsWith('https://') && typeof cfg.SUPABASE_PUBLISHABLE_KEY === 'string' && cfg.SUPABASE_PUBLISHABLE_KEY.startsWith('sb_publishable_');
const supabase = supabaseReady ? createClient(cfg.SUPABASE_URL, cfg.SUPABASE_PUBLISHABLE_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } }) : null;

let mode = localStorage.getItem('ad5_mode') === 'real' ? 'real' : 'demo';
let points = Number(localStorage.getItem('ad5_points') || 0);
let views = Number(localStorage.getItem('ad5_views') || 0);
let demoRand = Number(localStorage.getItem('ad5_demo_rand') || 0);
let transactions = safeJson(localStorage.getItem('ad5_demo_transactions'), []);
let busy = false;
let realWallet = null;
let currentUser = null;
let walletLoading = false;
let authResolved = false;

function safeJson(raw, fallback) { try { const value = JSON.parse(raw); return Array.isArray(value) ? value : fallback; } catch { return fallback; } }
function saveDemoWallet() {
  localStorage.setItem('ad5_demo_rand', demoRand.toFixed(2));
  localStorage.setItem('ad5_demo_transactions', JSON.stringify(transactions));
  localStorage.setItem('ad5_points', String(points));
  localStorage.setItem('ad5_views', String(views));
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function renderDemoWallet() {
  $('walletAvailable').textContent = zar(demoRand); $('walletPending').textContent = 'R0.00'; $('walletTotal').textContent = zar(demoRand);
  const list = $('transactions');
  if (!transactions.length) { list.innerHTML = '<p class="empty">No demo activity yet. Complete a sample clip to see a test entry here.</p>'; return; }
  list.innerHTML = transactions.slice().reverse().map(tx => `<div class="transaction"><div><b>${escapeHtml(tx.title)}</b><small>${escapeHtml(tx.date)} · simulated</small></div><strong>+${zar(tx.amount)}</strong></div>`).join('');
}
function renderMode() {
  const isDemo = mode === 'demo';
  $('demoMode').classList.toggle('active', isDemo); $('realMode').classList.toggle('active', !isDemo);
  $('modeNotice').className = 'notice ' + (isDemo ? 'demo-notice' : 'warning-notice');
  $('modeNotice').innerHTML = isDemo ? '<b>DEMO MODE</b><span>Test credits only. They have no cash value and cannot be withdrawn.</span>' : '<b>REAL-MONEY MODE · NOT A PAYOUT SERVICE</b><span>Sign in to view your verified account. Rewards and withdrawals remain disabled until sponsor and payout integrations are approved.</span>';
  $('topBalanceLabel').textContent = isDemo ? 'DEMO POINTS BALANCE' : 'REAL ACCOUNT STATUS';
  $('points').textContent = isDemo ? points.toLocaleString() : '—'; $('pointsUnit').textContent = isDemo ? 'pts' : 'not linked';
  $('topBalanceNote').textContent = isDemo ? 'Points are simulated. No cash or rewards are payable in this demo.' : 'Real balances are read from your authenticated AD5 account only.';
  $('demoEarnCard').classList.toggle('hidden', !isDemo); $('realEarnCard').classList.toggle('hidden', isDemo);
  $('demoWallet').classList.toggle('hidden', !isDemo); $('realWallet').classList.toggle('hidden', isDemo);
  $('howItWorks').textContent = isDemo ? 'Choose a sample clip → watch the countdown → collect demo points → explore the test wallet.' : 'Real rewards require an eligible sponsor event verified by the AD5 server.';
  $('rewardIntro').textContent = isDemo ? 'Demo points and sample Rand amounts cannot be redeemed. Real rewards will only appear after sponsor funding and server verification.' : 'Real rewards are not active yet. They require a funded sponsor campaign and server verification.';
  $('views').textContent = views + ' / ' + DEMO_DAILY_LIMIT; $('watch').disabled = busy || views >= DEMO_DAILY_LIMIT;
}
function renderRealWallet() {
  if (!realWallet) return;
  $('realAvailable').textContent = zar(realWallet.available_balance); $('realPending').textContent = zar(realWallet.pending_balance); $('realTotal').textContent = zar(realWallet.total_earned);
  $('realWalletMessage').textContent = 'Balance supplied by your authenticated AD5 database account.';
  const items = Array.isArray(realWallet.transactions) ? realWallet.transactions : [];
  $('realTransactions').innerHTML = items.length ? items.map(tx => `<div class="transaction"><div><b>${escapeHtml(tx.description || 'Wallet transaction')}</b><small>${escapeHtml(tx.created_at || '')}</small></div><strong>${escapeHtml(tx.amount_formatted || '')}</strong></div>`).join('') : '<p class="empty">No verified transactions yet.</p>';
}
function renderAuth() {
  const status = $('authStatus');
  $('authFields').classList.toggle('hidden', !!currentUser);
  $('signOut').classList.toggle('hidden', !currentUser);
  if (!supabase) status.textContent = 'Supabase configuration is missing or invalid. Check www/config.js.';
  else if (currentUser) status.textContent = 'Signed in as ' + currentUser.email + '. Your real wallet is linked to this account.';
  else status.textContent = 'Sign in or create an account to continue to AD5 Rewards ZA.';
}
function applyAccessGate() {
  const signedIn = authResolved && !!currentUser;
  $('dashboard').classList.toggle('hidden', !signedIn);
  $('accountCard').classList.toggle('hidden', signedIn);
}
function render() { $('views').textContent = views + ' / ' + DEMO_DAILY_LIMIT; $('watch').disabled = busy || views >= DEMO_DAILY_LIMIT; renderDemoWallet(); renderMode(); renderRealWallet(); renderAuth(); applyAccessGate(); }
function setAuthMessage(message) { $('authStatus').textContent = message; }
async function authAction(action) {
  if (!supabase) { setAuthMessage('Supabase configuration is invalid.'); return; }
  const email = $('authEmail').value.trim(); const password = $('authPassword').value;
  if (!email || !password) { setAuthMessage('Enter your email address and password.'); return; }
  if (password.length < 8) { setAuthMessage('Use a password with at least 8 characters.'); return; }
  $('signIn').disabled = true; $('signUp').disabled = true;
  try {
    if (action === 'signup') {
      const displayName = $('displayName').value.trim();
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
      if (error) throw error;
      if (data.session) { currentUser = data.user; authResolved = true; setAuthMessage('Account created and signed in.'); }
      else setAuthMessage('Registration received. Check your email to confirm the account, then sign in.');
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      currentUser = data.user; authResolved = true; setAuthMessage('Signed in successfully.');
    }
    render(); if (currentUser && mode === 'real') await loadRealWallet();
  } catch (error) { setAuthMessage(error?.message || 'Authentication failed.'); }
  finally { $('signIn').disabled = false; $('signUp').disabled = false; }
}
async function loadRealWallet() {
  if (!supabase) { $('realWalletMessage').textContent = 'Supabase is not configured.'; return; }
  if (walletLoading) return;
  const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
  const user = sessionData?.session?.user;
  currentUser = user || null; renderAuth();
  if (sessionError || !user) { realWallet = null; $('realAvailable').textContent = 'R—'; $('realPending').textContent = 'R—'; $('realTotal').textContent = 'R—'; $('realWalletMessage').textContent = 'Sign in to view your private real-account wallet. No balance is stored on this device.'; $('realTransactions').innerHTML = '<p class="empty">Sign in to load your account history.</p>'; return; }
  walletLoading = true; $('realWalletMessage').textContent = 'Loading verified account balance…';
  try {
    const { data: wallet, error: walletError } = await supabase.from('wallets').select('currency,available_cents,pending_cents,total_earned_cents,updated_at').eq('user_id', user.id).single();
    if (walletError) throw walletError;
    const { data: rows, error: rowsError } = await supabase.from('wallet_ledger').select('id,entry_type,amount_cents,description,created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(30);
    if (rowsError) throw rowsError;
    const money = cents => (Number(cents) / 100).toFixed(2);
    realWallet = { available_balance: money(wallet.available_cents), pending_balance: money(wallet.pending_cents), total_earned: money(wallet.total_earned_cents), transactions: (rows || []).map(row => ({ description: row.description, created_at: row.created_at, amount_formatted: `${Number(row.amount_cents) >= 0 ? '+' : '-'}R${money(Math.abs(Number(row.amount_cents)))}` })) };
    renderRealWallet(); $('realWalletMessage').textContent = 'Verified read-only ZAR balance. Rewards and withdrawals are not enabled.';
  } catch (error) {
    realWallet = null; $('realAvailable').textContent = 'R—'; $('realPending').textContent = 'R—'; $('realTotal').textContent = 'R—';
    $('realWalletMessage').textContent = 'Could not load wallet: ' + (error?.message || 'unknown error') + '. Check database policies and account confirmation.';
  } finally { walletLoading = false; }
}

$('demoMode').addEventListener('click', () => { mode = 'demo'; localStorage.setItem('ad5_mode', mode); render(); });
$('realMode').addEventListener('click', () => { mode = 'real'; localStorage.setItem('ad5_mode', mode); render(); loadRealWallet(); });
$('signIn').addEventListener('click', () => authAction('signin'));
$('signUp').addEventListener('click', () => authAction('signup'));
$('signOut').addEventListener('click', async () => { if (!supabase) return; const { error } = await supabase.auth.signOut(); if (error) setAuthMessage(error.message); currentUser = null; realWallet = null; authResolved = true; render(); });
if (supabase) {
  supabase.auth.onAuthStateChange((_event, session) => { currentUser = session?.user || null; authResolved = true; render(); if (mode === 'real' && currentUser) loadRealWallet(); });
  supabase.auth.getSession().then(({ data, error }) => { currentUser = data?.session?.user || null; authResolved = true; if (error) setAuthMessage(error.message); render(); if (mode === 'real' && currentUser) loadRealWallet(); }).catch(error => { authResolved = true; setAuthMessage(error?.message || 'Could not check your sign-in session.'); render(); });
}
document.querySelectorAll('nav button').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('nav button').forEach(item => item.classList.remove('active')); button.classList.add('active');
  document.querySelectorAll('.page').forEach(page => page.classList.add('hidden')); $(button.dataset.page).classList.remove('hidden');
  if (button.dataset.page === 'wallet' && mode === 'real') loadRealWallet();
}));
$('watch').addEventListener('click', () => {
  if (mode !== 'demo' || busy || views >= DEMO_DAILY_LIMIT) return;
  busy = true; render(); let seconds = 5; $('timerLabel').textContent = 'Demo countdown: ' + seconds + 's'; $('video').querySelector('.play').textContent = '⏳';
  const timer = setInterval(() => { seconds--; $('timerLabel').textContent = 'Demo countdown: ' + seconds + 's'; if (seconds <= 0) {
    clearInterval(timer); points += DEMO_POINTS_PER_CLIP; views++; demoRand = Number((demoRand + DEMO_RAND_PER_CLIP).toFixed(2));
    transactions.push({ title:'Completed 5-second demo clip', amount:DEMO_RAND_PER_CLIP, date:new Date().toLocaleString() }); saveDemoWallet();
    $('timerLabel').textContent = 'Demo complete — +10 points'; $('video').querySelector('.play').textContent = '✓'; busy = false; render();
  } }, 1000);
});
$('copy').addEventListener('click', async () => { try { await navigator.clipboard.writeText('AD5-DEMO'); $('copy').textContent = 'Copied demo code!'; } catch { $('copy').textContent = 'Code: AD5-DEMO'; } });
render();
